const mongoose = require('mongoose');

const schema = mongoose.Schema;

const alldata = {
    Parents:[{
        type:mongoose.Schema.Types.ObjectId,
        ref:'DataModel'
    }],
    Category:{
        type:String
    },
    Name:{
        type:String
    },
    Target_Sales:{
        type:Number
    },
    Total_Sales:{
        type:Number
    },
    Children:[{
        type:mongoose.Schema.Types.ObjectId,
        ref:'DataModel'
    }]
}

const DataSchema = schema(alldata);

module.exports = mongoose.model.DataModel || mongoose.model('DataModel',DataSchema);
