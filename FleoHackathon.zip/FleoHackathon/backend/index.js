const express = require('express');
const app = express();
const mongoose = require('mongoose');
const route = require('./Routes/Dataroutes');

mongoose.connect('mongodb://localhost:27017/fleohackathon',{useNewUrlParser: true, useUnifiedTopology: true})
.then((data)=>{
    console.log('Successfully Connected');
})
.catch((e)=>{
    console.log(e);
})


app.use(route);

app.listen(5000,(data)=>{
    console.log("Listening At Port 5000");
})