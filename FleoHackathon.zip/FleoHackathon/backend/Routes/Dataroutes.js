const express = require('express');
const { model } = require('mongoose');
const route = express.Router();
const DataModel = require('../Models/DataModel');

route.post('/addnewdata',async(req,res)=>{
    const {body,query}=req;
    if(!body || body.length<1)
    {
        if(query.parent && query.parent.length>0)
        {
            console.log(query);
            const Parent = await DataModel.find({Name:query.parent});
            // console.log(Parent);
            const newdata = await DataModel({Category:query.category,Name:query.name,Target_Sales:query.target,Total_Sales:query.total})
            Parent[0].Children.push(newdata);
            const savedData = await Parent[0].save();
            const checkedUserData = await newdata.save();
            console.log(savedData);
            checkedUserData.Parents.push(Parent[0]);
            const newCheckedUserData = await checkedUserData.save();
            res.send({"message":"Successfully Inserted",data:newCheckedUserData})    
            // res.send({"message":"Successfully Inserted"})    
        }
        else
        {
            console.log(query);
            const newdata = await DataModel({Category:query.category,Name:query.name,Target_Sales:query.target,Total_Sales:query.total})
            // await parentCheck.save();
            const checkedUserData = await newdata.save();
            res.send({"message":"Successfully Inserted",data:checkedUserData})    
        }
    }
    else{
        if(body.parent && body.parent.length>0)
        {
            console.log(body);
            const Parent = await DataModel.find({Name:body.parent})
            const newdata = await DataModel({Category:body.category,Name:body.name,Target_Sales:body.target,Total_Sales:body.total})
            Parent[0].Children.push(newdata);
            const savedData = await Parent[0].save();
            const checkedUserData = await newdata.save();
            console.log(savedData);
            checkedUserData.Parents.push(Parent[0]);
            const newCheckedUserData = await checkedUserData.save();
            res.send({"message":"Successfully Inserted",data:newCheckedUserData})    
        }
        else{
            console.log(body);
            const newdata = await DataModel({Category:body.category,Name:body.name,Target_Sales:body.target,Total_Sales:body.total})
            const checkedUserData = await newdata.save();
            res.send({"message":"Successfully Inserted",data:checkedUserData})    
        }
    }
})

route.post('/getParent',async(req,res)=>{
    const {body,query}=req;
    if(!body)
    {
        console.log(query);
        let presentname=await DataModel.find({Name:query.name})
        let allparents=[];
        console.log(presentname[0].Parents[0]);
        while(presentname.length>0)
        {
            let newparent;
            if(presentname)
            {
                newparent = await DataModel.findById(presentname[0].Parents[0]);
            }
            else{
                break;
            }
            if(newparent)
            {
                allparents.push(newparent);
                presentname=newparent;
            }
            else{
                break;
            }
            console.log(allparents)
        }
        res.send({data:allparents});
    }
    else
    {
        console.log(body);
        let presentname=await DataModel.find({Name:body.name})
        let allparents=[];
        while(presentname)
        {
            let newparent;
            if(presentname)
            {
                newparent = await DataModel.findById(presentname[0].Parents[0]);
            }
            else{
                break;
            }
            if(newparent)
            {
                allparents.push(newparent);
                presentname=newparent;
            }
            else{
                break;
            }
            console.log(allparents)
        }
        res.send({data:allparents});
    }
})

module.exports = route;